import { Component, OnInit } from '@angular/core';
import { FormControl,FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DialogComponent } from '../dialog/dialog.component';
import {MatDialog,MatDialogRef} from '@angular/material';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import {MatSnackBar} from '@angular/material/snack-bar';
import { MainServiceService } from '../main-service.service';
import {Router,ActivatedRoute, Route} from   '@angular/router'; 
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-signin-dialog',
  templateUrl: './signin-dialog.component.html',
  styleUrls: ['./signin-dialog.component.css']
})
export class SigninDialogComponent implements OnInit {
  // authError: string;
  authError:any;
  myform:FormGroup;
  visiting_place: string;

  constructor(public dialog:MatDialog,private fb:FormBuilder,private _loginService:LoginService,
    private dialogRef:MatDialogRef<SigninDialogComponent>, 
     private http: HttpClient,private _snackBar:MatSnackBar,
     private _mainService:MainServiceService,
     private route:ActivatedRoute,
     private router:Router) { }

  ngOnInit() {
    this.myform=this.fb.group(
      {
           
            email:['',[Validators.required,Validators.minLength(4),Validators.email]],
            password:['',[Validators.required,Validators.minLength(6),Validators.pattern('^[a-zA-Z0-9]+$')]]
        
      });
      this._loginService.eventAuthError$.subscribe(data=>
        {
          this.authError=data;
        })
  }
  goBack()
  {
    this.dialogRef.close();
    this.dialog.open(DialogComponent,{disableClose:true});
  }
  onSubmit(form:{value:any}):void
  {
       if(this.myform.invalid==true)
       {
          return;
       }
       else
       {
            alert("Signing in...!!!!!!!!!");
            let data=Object.assign(this.myform.value);
            this.http.post('/api/v1/customer/check', data).subscribe((data:any) => {
            

              this._mainService.setUser(data.firstName);
              this._mainService.setMail(data.email);
              alert(data.firstName);
              this.openSnackBar(data.firstName);
              this.dialogRef.close();
              
              

            });
       }
  }
  openSnackBar(firstName: any) {
    this._snackBar.open('Successfully  Signed in as ',firstName,{
      duration:3000,
      verticalPosition: 'top'
    });
  }

}
