const mongoose=require('mongoose');
const express=require('express');
const router=express.Router;


router.post('/',async(req,res,next)=>
{
         const data=req.body;
         try{
                   const dt=JSON.parse(data);
                   console.log(dt.user);
         }
         catch(err){

         }
         
});