import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { CareersComponent } from './careers/careers.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { ContactComponent } from './contact/contact.component';
import { AffiliatesComponent } from './affiliates/affiliates.component';
import { MainDialogComponent } from './main-dialog/main-dialog.component';
import { YoutubeDialogComponent } from './youtube-dialog/youtube-dialog.component';
import { TripDialogComponent } from './trip-dialog/trip-dialog.component';
// import { DisplayUserDataComponentComponent } from './display-user-data-component/display-user-data-component.component';
const routes: Routes = [
   {path:'', redirectTo:'home',pathMatch:'prefix'},
  {path:'home',component:HomeComponent,data:{title:'Plan Trips with Videos - SeeVoov'},
   children:[
     {
       path:'plan-trip/:visiting_place',
       children:[
         {path:'choose-travel-kind',component:MainDialogComponent},
         {path:'where-to-go',component:YoutubeDialogComponent},
         {path:'trip-information',component:TripDialogComponent}
       ]
     }
   ]},
  {path:'about',component:AboutComponent},
  {path:'careers',component:CareersComponent},
  {path:'affiliates',component:AffiliatesComponent},
  {path:'terms',component:TermsConditionsComponent},
  {path:'contact',component:ContactComponent}
// {path:'user/:uid',component:DisplayUserDataComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
