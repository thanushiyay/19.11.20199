export interface  dett
{
    
        title:string,
        details:[
            {
                   name:string,
                   image:string,
                   content:string,
                   embed:string,
                   rating:string,
                   est_hrs:string
                  
            }
        ]
}