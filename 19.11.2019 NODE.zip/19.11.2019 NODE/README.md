# Simple Application via Angular + Node + Express

A step by step tutorial on how to create this API 
https://medium.com/@jsmuster/simple-application-with-angular-6-node-js-express-2873304fff0f
