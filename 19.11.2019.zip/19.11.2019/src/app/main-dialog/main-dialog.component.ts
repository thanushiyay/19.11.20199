import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import { MainServiceService } from '../main-service.service';
import { YoutubeDialogComponent } from '../youtube-dialog/youtube-dialog.component';
// import {Router,ActivatedRoute} from '@angular/router';
import {Router,ActivatedRoute} from   '@angular/router'; 
import {Title} from '@angular/platform-browser';
import { SetTitleService } from '../set-title.service';
// import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
@Component({
  selector: 'app-main-dialog',
  templateUrl: './main-dialog.component.html',
  styleUrls: ['./main-dialog.component.css']
})
export class MainDialogComponent implements OnInit {
  data:string;
  visiting_place: string;
  title: string;
  constructor(public dialog:MatDialog,private _mainService:MainServiceService
    ,private router:Router,private route:ActivatedRoute,private _titleService:Title,
    private _setTitleService:SetTitleService,private  dialogRef:MatDialogRef<MainDialogComponent>) {
    debugger;
}

  ngOnInit() {
    this.data=this._mainService.getOption();
    // if(this.router.url==)
    // this.title="Plan your trip to " + this.data + "- SeeVoov";
    // this._titleService.setTitle(this.title);
    this._setTitleService.checkPageTitle();
  }
  openYoutubeDialog(seeing_place:any)
  {
     this._mainService.setSeeing_place(seeing_place);
     this.dialogRef.close();
     this.visiting_place=this._mainService.getOption();
     this.router.navigate(['plan-trip',this.visiting_place,'where-to-go'],{relativeTo:this.route});
     this.dialog.open(YoutubeDialogComponent,{ disableClose: true });
     this._setTitleService.checkPageTitle();
  }
  matDialogClose()
  {
    this.dialog.afterAllClosed.subscribe(result=>
      {
           this.router.navigate(['../../../'],{relativeTo:this.route});
           setTimeout(()=>
           {
                this._setTitleService.checkPageTitle();
           },5);
      });
    
      
  }
 

}
