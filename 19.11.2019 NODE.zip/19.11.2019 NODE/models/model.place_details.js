const mongoose=require('mongoose');
const  schema=new mongoose.Schema(
    {
         place_name:String,
         place_details:[
             {
                  title:String,
                  details:[
                      {
                          name:String,
                          image:String,
                          content:String,
                          embed:String,
                          rating:Number,
                          est_hrs:Number
                      }
                  ]
             }
         ]
    }
);
const   Place_details=mongoose.model('Place_details',schema);
module.exports=Place_details;